﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Relation
{
    class Engine
    {
        public int Rpm { get; set; }
        public string Type { get; set; }

        public void Start()
        {

        }

        public void Accelerate()
        {

        }
    }
}
