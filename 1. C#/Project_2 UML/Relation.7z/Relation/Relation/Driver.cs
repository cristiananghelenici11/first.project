﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Relation
{
    class Driver
    {
        // agregarea
        private Car car;

        public Driver(Car car)
        {
            this.car = car;
        }
    }
}
