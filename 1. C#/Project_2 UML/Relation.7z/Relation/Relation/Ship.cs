﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Relation

    class Ship : Vehicle
    {
        public int LifeJacketNumber { get; set; }

    }
}
