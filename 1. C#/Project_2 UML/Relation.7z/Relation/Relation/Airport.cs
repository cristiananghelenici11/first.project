﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Relation
{
    class Airport
    {
        public string _Location { get; set; }
        public double Area { get; set; }

        public Aircraft Aircraft { get; set; }

    }
}
