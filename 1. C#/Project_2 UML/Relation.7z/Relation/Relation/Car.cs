﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Relation
{
    class Car : Vehicle
    {
        public int WheelNumber { get; set; }
        public string ModelType { get; set; }

        public void Refuel(string gas)
        {

        }
    }
}
