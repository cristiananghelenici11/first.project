﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Relation
{
    class Aircraft : Vehicle
    {
        public int ParachuteNumber { get; set; }



    }


}
